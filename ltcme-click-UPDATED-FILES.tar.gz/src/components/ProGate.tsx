import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { getMyEntitlement } from "@/lib/payments.functions";
import { PlansInline } from "@/components/PlansInline";
import { Shield } from "lucide-react";

/** Static mainnet indicator — LTCme.click is mainnet only. */
export function NetworkToggle() {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-background/60 px-2.5 py-1 text-[11px] text-muted-foreground">
      <span className="h-1.5 w-1.5 rounded-full bg-primary" />
      Litecoin Mainnet
    </span>
  );
}

/**
 * Client entitlement hint backed by server getMyEntitlement.
 * Server AI/chat remains authoritative.
 */
export function useHeightenedSecurity(): {
  loading: boolean;
  active: boolean;
  refresh: () => void;
} {
  const [loading, setLoading] = useState(true);
  const [active, setActive] = useState(false);
  const getEnt = useServerFn(getMyEntitlement);

  async function refresh() {
    setLoading(true);
    try {
      const ent = await getEnt();
      setActive(!!ent.active);
    } catch {
      setActive(false);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return { loading, active, refresh };
}

export function HeightenedSecurityGate({
  children,
  featureLabel = "this Heightened Security feature",
}: {
  children: React.ReactNode;
  featureLabel?: string;
}) {
  const { loading, active } = useHeightenedSecurity();

  if (loading) {
    return (
      <div className="rounded-2xl border border-border bg-card/40 p-6 text-sm text-muted-foreground">
        Checking subscription…
      </div>
    );
  }

  if (active) return <>{children}</>;

  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-primary/30 bg-primary/5 p-4 flex items-start gap-3">
        <Shield className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
        <div>
          <div className="text-sm font-medium">Heightened Security required</div>
          <p className="text-xs text-muted-foreground mt-1">
            Unlock {featureLabel} by paying with Litecoin ($5.99/month equivalent). Your self-custody wallet,
            seed recovery, and ordinary send/receive remain available without a subscription.
          </p>
        </div>
      </div>
      <PlansInline />
    </div>
  );
}
